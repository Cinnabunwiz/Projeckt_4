const name = document.getElementById('name')
const email = document.getElementById("email")
const form = document.getElementById('form')
const errorElement = document.getElementById('error')

form.addEventListener('submit', (e) =>{
let messages = []
    if(name.value===''||name.value==null)
    if(name.length <= 1){
    messages.push('Name is required')}

    if(discount.value == Lehman College)
    document.getElementById('Author').innerHTML = "Author ($200)"
    document.getElementById('Participant').innerHTML = "Participant ($150)"
    document.getElementById('Student').innerHTML = "Student ($50)"



    e.preventDefault()
    errorElement.innerText = messages.joint(',')
})
